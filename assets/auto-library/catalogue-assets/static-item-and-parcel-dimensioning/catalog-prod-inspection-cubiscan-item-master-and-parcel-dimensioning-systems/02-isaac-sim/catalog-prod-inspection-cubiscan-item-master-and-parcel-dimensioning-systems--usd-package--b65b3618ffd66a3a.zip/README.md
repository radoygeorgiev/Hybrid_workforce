# Cubiscan 325 — illustrative mobile workstation

This is a reference-informed exterior representing one product within the catalogue's item-master dimensioning family. The cart, weighing platform, manually positioned gate, touchscreen, laptop tray and optional camera are modeled as a static scene. The machine chassis is approximately 1.25 × 0.97 m, based on the manufacturer brochure; the stand, gate details, camera and internal construction are illustrative. The sample item is stationary and measurement, weighing, gate movement and software are not simulated.

References: [Cubiscan 325 manufacturer page](https://cubiscan.com/item-master-data-solutions-cubiscan-325/) and [product brochure](https://info.cubiscan.com/hubfs/Brochures/CS%20325/CS325%20Product%20Brochure%202-2024.pdf). The brochure's dimensions refer to a version of the product and do not verify every detail of this model.

The editable `scene.blend`, browser `equipment.glb`, and `cubiscan.usdc` with `textures/` are static visual assets. Isaac Sim import and rendering have not been checked; there are no physics or controls. Rebuild with Blender `--python-exit-code 1 --python build.py`.
