from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
p=Path(__file__).resolve().parent/'cubiscan.usdc';s=Usd.Stage.Open(str(p));assert s
assert str(s.GetDefaultPrim().GetPath())=='/Cubiscan325'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
_,_,missing=UsdUtils.ComputeAllDependencies(str(p));assert not missing,missing
meshes=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh')
uvs=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(x).GetPrimvar('st'))
textures=sum(1 for x in s.Traverse() if x.GetTypeName()=='Shader' and UsdShade.Shader(x).GetIdAttr().Get()=='UsdUVTexture')
opacity=[]
for x in s.Traverse():
 if x.GetTypeName()=='Shader' and UsdShade.Shader(x).GetIdAttr().Get()=='UsdPreviewSurface':
  i=UsdShade.Shader(x).GetInput('opacity')
  if i and i.Get() is not None and i.Get()<.5:opacity.append(i.Get())
assert meshes>50 and uvs>50 and textures>=4 and opacity,(meshes,uvs,textures,opacity)
print('CUBISCAN_USD_CHECK',meshes,uvs,textures,'glass opacity',opacity,'no unresolved dependencies')
