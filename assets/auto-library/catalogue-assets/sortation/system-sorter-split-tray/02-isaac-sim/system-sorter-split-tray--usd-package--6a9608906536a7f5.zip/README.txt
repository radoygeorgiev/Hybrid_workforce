Generic split-tray visual concept in meters and Z-up. No motion, controls, engineering or safety certification. Not tested in Isaac Sim.
