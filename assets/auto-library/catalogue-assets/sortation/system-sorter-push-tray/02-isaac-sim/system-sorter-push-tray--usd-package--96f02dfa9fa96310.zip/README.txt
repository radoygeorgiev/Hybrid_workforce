Generic push-tray sorter static visual concept in meters and Z-up. No simulated transfers or controls; not engineering or safety certification. Not tested in Isaac Sim.
