Generic cross-belt line static visual concept in meters and Z-up. Generic surface maps; transfer and controls are not simulated. Not tested in Isaac Sim.
