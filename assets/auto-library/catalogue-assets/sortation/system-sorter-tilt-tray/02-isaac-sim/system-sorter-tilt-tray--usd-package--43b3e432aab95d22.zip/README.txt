Generic tilt-tray sorter, static visual concept in meters and Z-up. No motion, controls, or engineering and safety certification. Not tested in Isaac Sim.
