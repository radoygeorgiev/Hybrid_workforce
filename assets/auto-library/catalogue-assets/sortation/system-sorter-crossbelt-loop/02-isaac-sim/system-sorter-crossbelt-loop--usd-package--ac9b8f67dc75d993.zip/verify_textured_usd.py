from pxr import Usd,UsdGeom,UsdShade,UsdUtils
from pathlib import Path
import json,sys,math
D=Path(__file__).resolve().parent;p=D/'crossbelt-textured.usdc';s=Usd.Stage.Open(str(p));assert s
sys.path.insert(0,str(D));from path import pose,parcel_pose,FRAMES,END
assert str(s.GetDefaultPrim().GetPath())=='/CrossBelt'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
assert s.GetStartTimeCode()==1 and s.GetEndTimeCode()==END and s.GetTimeCodesPerSecond()==24
for i in range(1,101):
 root=s.GetPrimAtPath(f'/CrossBelt/crossbelt/Carrier_motion_{i:03d}');assert root,i
 for frame in (1,331,661,991,1321):
  cache=UsdGeom.XformCache(Usd.TimeCode(frame));xyz=cache.GetLocalToWorldTransform(root).ExtractTranslation();expected=pose(i,frame)
  assert math.dist(xyz,expected[:3])<1e-4,(i,frame,xyz,expected)
  carrier=root.GetChild(f'crossbelt_carrier_{i}');assert carrier,i
  c=cache.GetLocalToWorldTransform(carrier).ExtractTranslation();assert math.dist(xyz,c)<1e-4,(i,frame,xyz,c)
 if i%4==0 and i!=4:
  child=root.GetChild(f'Carrier_parcel_{i:03d}');assert child,i
  for frame in (1,661):
   cache=UsdGeom.XformCache(Usd.TimeCode(frame));a=cache.GetLocalToWorldTransform(root).ExtractTranslation();b=cache.GetLocalToWorldTransform(child).ExtractTranslation()
   assert abs(a[0]-b[0])<1e-4 and abs(a[1]-b[1])<1e-4 and b[2]>a[2],(i,frame,a,b)
root=s.GetPrimAtPath('/CrossBelt/Demonstration_discharge_parcel_root');assert root
assert root.GetChild('Carrier_parcel_004')
for frame in (1,821,831,880,1321):
 xyz=UsdGeom.XformCache(Usd.TimeCode(frame)).GetLocalToWorldTransform(root).ExtractTranslation();expected=parcel_pose(frame)
 assert math.dist(xyz,expected[:3])<1e-4,(frame,xyz,expected)
_,_,unresolved=UsdUtils.ComputeAllDependencies(str(p));assert not unresolved,unresolved
textures=0;color=0;rough=0;uv_meshes=0
for prim in s.Traverse():
 if prim.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(prim).GetPrimvar('st'):uv_meshes+=1
 if prim.GetTypeName()!='Shader':continue
 shader=UsdShade.Shader(prim);ident=shader.GetIdAttr().Get()
 if ident=='UsdUVTexture':textures+=1
 if ident=='UsdPreviewSurface':
  for name in ('diffuseColor','roughness'):
   inp=shader.GetInput(name)
   if inp and inp.HasConnectedSource():
    if name=='diffuseColor':color+=1
    else:rough+=1
assert textures>=8 and color>=4 and rough>=4 and uv_meshes>0,(textures,color,rough,uv_meshes)
print('CROSSBELT_TEXTURED_USD_VALIDATED',json.dumps({'texture_shaders':textures,'color_connections':color,'roughness_connections':rough,'uv_meshes':uv_meshes,'unresolved':unresolved}),flush=True)
