"""Counterclockwise stadium centerline, metres in Z-up scene coordinates."""
import math
R=3.;STRAIGHT=42.;TOTAL=2*STRAIGHT+2*math.pi*R
END=1321;STEP=5
FRAMES=list(range(1,END,STEP))+[END]
def pose(index,frame):
 distance=3+(index-1)*TOTAL/100+TOTAL*(frame-1)/(END-1)
 lap=math.floor(distance/TOTAL);s=distance-lap*TOTAL
 if s<STRAIGHT:x=-21+s;y=-3;ang=0
 elif s<STRAIGHT+math.pi*R:
  t=(s-STRAIGHT)/R;x=21+R*math.sin(t);y=-R*math.cos(t);ang=t
 elif s<2*STRAIGHT+math.pi*R:
  t=s-(STRAIGHT+math.pi*R);x=21-t;y=3;ang=math.pi
 else:
  t=(s-(2*STRAIGHT+math.pi*R))/R;x=-21-R*math.sin(t);y=R*math.cos(t);ang=math.pi+t
 return x,y,.9,ang+lap*2*math.pi
# One deliberately illustrative lateral discharge to the outfeed at x=2 m.
DFRAMES=sorted(set(FRAMES+[821,831,880]))
def parcel_pose(frame):
 x,y,z,a=pose(4,frame)
 if frame<=821:return x,y,z,a
 endx=pose(4,831)[0]
 if frame<=831:return x,3+1.10*(frame-821)/10,z,math.pi
 if frame<=880:return endx,4.10+1.62*(frame-831)/49,z,math.pi
 return endx,5.72,z,math.pi
