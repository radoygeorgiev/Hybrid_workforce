# Cruiser 360 with varied pallet contents

This is the larger Cruiser 360 concept with an opt-in population of 900 existing counted pallet loads. The compatible library recipes assign cartons, drums, pails, reels, sacks, crates and several coverings to the inventory. The inventory identities and initial staged shuttle pose are retained. The materials and products are illustrative; this is not a stock list or OEM engineering model.

The shuttle envelope follows Addverb's published dimensions: https://addverb.com/automated-warehouse-robots/asrs-system/4-way-pallet-shuttle/. The model remains a static visual concept. Pallet restraint, weights and center of gravity, load clearance, lift contact, shuttle approach, controls, safety and Isaac Sim rendering remain unverified.
