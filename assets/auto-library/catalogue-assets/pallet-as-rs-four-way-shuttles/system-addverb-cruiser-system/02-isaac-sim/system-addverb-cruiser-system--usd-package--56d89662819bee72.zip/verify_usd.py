from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
p=Path(__file__).resolve().parent/'cruiser360.usdc';s=Usd.Stage.Open(str(p));assert s
assert str(s.GetDefaultPrim().GetPath())=='/Cruiser360'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
_,_,missing=UsdUtils.ComputeAllDependencies(str(p));assert not missing,missing
m=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh');u=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(x).GetPrimvar('st'));t=sum(1 for x in s.Traverse() if x.GetTypeName()=='Shader' and UsdShade.Shader(x).GetIdAttr().Get()=='UsdUVTexture')
assert m>100 and u>100 and t>=4,(m,u,t)
transparent=[]
for prim in s.Traverse():
 if prim.GetTypeName()!='Shader':continue
 shader=UsdShade.Shader(prim)
 if shader.GetIdAttr().Get()!='UsdPreviewSurface':continue
 opacity=shader.GetInput('opacity')
 if opacity and opacity.Get() is not None and opacity.Get()<.99:transparent.append(str(prim.GetPath()))
assert transparent,'No authored transparent PreviewSurface found for pallet coverings'
print('CRUISER_USD_CHECK',m,u,t,'no unresolved dependencies')
print('TRANSPARENT_PREVIEW_SURFACES',len(transparent))
