"""Inspect the composed USD locally, including referenced assets and instances."""
import json
from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
D=Path(__file__).resolve().parent
path=D/'skycube-large.usda';stage=Usd.Stage.Open(str(path));assert stage
assert stage.GetDefaultPrim().GetPath().pathString=='/SkyCube'
assert UsdGeom.GetStageUpAxis(stage)==UsdGeom.Tokens.z
assert UsdGeom.GetStageMetersPerUnit(stage)==1
pallets=stage.GetPrimAtPath('/SkyCube/StoredPallets').GetChildren();assert len(pallets)==1017
assert all(p.IsInstance() for p in pallets)
assert all(p.GetPrimIndex().IsValid() for p in pallets)
assert stage.GetStartTimeCode()==1 and stage.GetEndTimeCode()==550 and stage.GetTimeCodesPerSecond()==24
robot=stage.GetPrimAtPath('/SkyCube/P800R_floor_pickup_4');moving=stage.GetPrimAtPath('/SkyCube/StoredPallets/Pallet_1016');assert robot and moving
for frame,x,y in ((1,6.75,15.05),(50,6.75,16.8),(105,10.65,16.8),(225,10.65,3.5),(250,12.8,3.5),(550,6.75,15.05)):
 cache=UsdGeom.XformCache(Usd.TimeCode(frame));rm=cache.GetLocalToWorldTransform(robot);pm=cache.GetLocalToWorldTransform(moving);r=rm.ExtractTranslation();p=pm.ExtractTranslation()
 assert abs(r[0]-x)<1e-4 and abs(r[1]-y)<1e-4,(frame,r)
 assert abs(p[0]-x)<1e-4 and abs(p[1]-y)<1e-4 and abs(p[2]-.30)<1e-4,(frame,p)
 for row in range(2):
  for col in range(2):assert abs(rm[row][col]-pm[row][col])<1e-4,(frame,row,col)
for i in range(1,5):
 obj=stage.GetPrimAtPath(f'/SkyCube/P800R_floor_pickup_{i}');assert obj and any(p.GetTypeName()=='Mesh' for p in Usd.PrimRange(obj))
_,_,unresolved=UsdUtils.ComputeAllDependencies(str(path));assert not unresolved,unresolved
textures=0;roughness=0
for prim in stage.Traverse():
 if prim.GetTypeName()!='Shader':continue
 shader=UsdShade.Shader(prim)
 if shader.GetIdAttr().Get()=='UsdUVTexture':textures+=1
 if shader.GetIdAttr().Get()=='UsdPreviewSurface':
  inp=shader.GetInput('roughness')
  if inp and inp.HasConnectedSource():roughness+=1
assert textures>=5 and roughness>=4,(textures,roughness)
# Pallet prototypes are USD instances, so regular stage traversal does not
# descend into them. Check their own material graph independently.
proto=Usd.Stage.Open(str(D/'pallet-0.usdc'));assert proto
proto_rough=0;proto_color=0
for prim in proto.Traverse():
 if prim.GetTypeName()!='Shader':continue
 sh=UsdShade.Shader(prim)
 if sh.GetIdAttr().Get()!='UsdPreviewSurface':continue
 for name in ('roughness','diffuseColor'):
  inp=sh.GetInput(name)
  if inp and inp.HasConnectedSource():
   if name=='roughness':proto_rough+=1
   else:proto_color+=1
assert proto_rough>=1 and proto_color>=1,(proto_rough,proto_color)
bound=UsdGeom.BBoxCache(Usd.TimeCode.Default(),[UsdGeom.Tokens.default_]).ComputeWorldBound(stage.GetDefaultPrim()).ComputeAlignedRange()
print('USD_VALIDATED',json.dumps({'instance_count':len(pallets),'structure_textures':textures,'structure_roughness':roughness,'prototype_roughness':proto_rough,'prototype_color':proto_color,'unresolved':unresolved,'min':list(bound.GetMin()),'max':list(bound.GetMax())}),flush=True)
