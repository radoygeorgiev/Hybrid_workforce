# BALYO LOWY visual reconstruction

- [BALYO LOWY official product page](https://www.balyo.com/agv-stackers/lowy): reference image and listed 2350 × 811 × 2327 mm overall size for the illustrated configuration; this series has variants.
- [BALYO LOWY product image](https://www.balyo.com/hs-fs/hubfs/Files/Product-Pages/Lowy/Lowy-Intro-Image.jpg?height=700&width=466): visual reference for dark covered power unit, shorter mast, pallet support legs, control bridge and raised 3D LiDAR.

External vehicle shape and machine subassemblies are visual approximations. Exact housing profiles, wheel placement, fork geometry, sensor package, electrical system and manual controls are inferred. The static concept is not OEM CAD; its motion, safety behavior, lifting capacity and precise clearance are not validated.
