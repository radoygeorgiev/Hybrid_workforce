Open lowy.usdc. Static BALYO LOWY reference-informed visual model, metres and Z up. See REFERENCES.md for provenance and limitations.
