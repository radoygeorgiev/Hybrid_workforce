Open apex2000g.usdc. Static reference-informed ForwardX Apex 2000-G visual model, metres and Z up. See REFERENCES.md for sources and limitations.
