# ForwardX Apex 2000-G visual reconstruction

- [ForwardX Apex product family](https://www.forwardx.com/apex-series/): distinguishes the low-lift Apex 2000 pallet jack from the high-lift stacker family; its published dimensions describe Apex 2000 and are not asserted as the 2000-G specifications.
- [ForwardX case study naming Apex 2000-G](https://www.forwardx.com/case/highline-warren-auto-parts-30-flex-scb-amrs-in-california/).
- [ForwardX company-community product announcement](https://www.iianews.com/ca/_01-ABC00000000000368442.shtml), and its [product image](https://www.iianews.com/resupload/00000000000000000011/116002009002/1766664471120_1.png): appearance of low-lift fork jack, tall sensor crossbar, picking screen and tiller.

The vehicle body, controls and internal details are a static visual interpretation, not manufacturer CAD. Exact 2000-G dimensions, sensor layout, lifting mechanisms, motions and safety functions remain unverified. Nominal 1.2 m fork length is only informed by the related Apex 2000 family, not claimed as a confirmed 2000-G dimension.
