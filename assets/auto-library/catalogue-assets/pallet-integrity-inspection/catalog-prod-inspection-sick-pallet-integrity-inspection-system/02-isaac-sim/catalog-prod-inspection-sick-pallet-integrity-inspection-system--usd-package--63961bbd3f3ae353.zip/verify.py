from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
p=Path(__file__).resolve().parent/'pais.usdc';s=Usd.Stage.Open(str(p));assert s
assert str(s.GetDefaultPrim().GetPath())=='/PalletInspection'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
_,_,missing=UsdUtils.ComputeAllDependencies(str(p));assert not missing,missing
meshes=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh')
uvs=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(x).GetPrimvar('st'))
textures=sum(1 for x in s.Traverse() if x.GetTypeName()=='Shader' and UsdShade.Shader(x).GetIdAttr().Get()=='UsdUVTexture')
assert meshes>80 and uvs>80 and textures>=2,(meshes,uvs,textures)
print('PAIS_USD_CHECK',meshes,uvs,textures,'no unresolved dependencies')
