Open vne.usdc. Static reference-informed VisionNav VNE20-66 visual model, metres and Z up. See REFERENCES.md for provenance and limitations.
