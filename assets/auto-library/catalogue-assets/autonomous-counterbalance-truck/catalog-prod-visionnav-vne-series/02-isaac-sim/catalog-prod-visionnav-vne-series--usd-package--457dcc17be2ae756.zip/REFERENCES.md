# VisionNav VNE20-66 visual reconstruction

- [VisionNav VNE20-66 product page](https://www.visionnav.com/product/detail87.html): reference exterior and vehicle category, with 2 t capacity and 3 m fork-lift height for that configuration.
- [VisionNav model comparison](https://www.visionnav.com/service/index53.html?proid=95%2C92%2C87%2C113%2C125%2C122%2C87): VNE20-66 fork dimensions 1195 × 100 × 40 mm.

The red rear cover, dark body, exposed dual mast, wheels, sensor bridge and forklift details are reconstructed from the product image. Vehicle dimensions other than fork geometry, optical layout, mechanical details and body panels are illustrative; the title is a series entry and this is one VNE20-66-inspired representative. The model is static, has no validated articulation, sensing, traffic or safety controls and is not OEM CAD.
