# Geek+ shelf-to-person — warehouse-scale concept

The visual layout has 128 mobile racks, six levels, 500 stored tote positions, 18 parked P800-style robots, six pick stations and six illustrative order put-walls. The racks and robots come from the existing reusable library. The fleet was moved behind the rack field to leave the pick-station operator side clear. Generic surface maps were applied to concrete, alloy, bins and rubber. The operator furniture and configuration are illustrative, not manufacturer CAD.

The [Geek+ case study](https://www.geekplus.com/case-studies/geek-and-kv-elektro-modernize-distribution-with-shelf-to-person-robotics) describes robots carrying mobile racks to workstations and 2.8 m, six-shelf racks. This scene uses a 2.74 m concept rack. The modeled entry check is geometric only; loaded clearance, center of gravity, lift contact, rack stability, travel routes, guarding, station ergonomics, throughput, safety, controls, robot motion and Isaac Sim appearance remain unverified. It is a static visual scene, not an engineered facility.

The original generator outputs are retained alongside `refined.blend`, browser `refined.glb` and `geek-shelf.usdc` with relative textures. Blender preview lights are not included in USD. Rebuild using `build_equipment.py` followed by `refine.py` and `export_usd.py`.
