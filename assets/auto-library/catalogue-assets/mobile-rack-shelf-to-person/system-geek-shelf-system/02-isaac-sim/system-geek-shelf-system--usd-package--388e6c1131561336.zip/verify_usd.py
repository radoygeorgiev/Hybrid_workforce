from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
p=Path(__file__).resolve().parent/'geek-shelf.usdc';s=Usd.Stage.Open(str(p));assert s
assert str(s.GetDefaultPrim().GetPath())=='/GeekShelf'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
_,_,missing=UsdUtils.ComputeAllDependencies(str(p));assert not missing,missing
m=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh');u=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(x).GetPrimvar('st'));t=sum(1 for x in s.Traverse() if x.GetTypeName()=='Shader' and UsdShade.Shader(x).GetIdAttr().Get()=='UsdUVTexture')
assert m>100 and u>100 and t>=4,(m,u,t)
print('GEEK_SHELF_USD_CHECK',m,u,t,'no unresolved dependencies')
