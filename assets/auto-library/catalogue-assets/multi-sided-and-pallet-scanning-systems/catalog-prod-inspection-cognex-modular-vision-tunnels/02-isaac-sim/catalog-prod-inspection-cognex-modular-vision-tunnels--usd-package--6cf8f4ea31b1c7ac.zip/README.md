# Cognex modular vision tunnel — illustrative system

This static concept illustrates a multi-reader tunnel with split belt sections and an underside reading gap. Seven linked DataMan 470-style reader proxies, two belt conveyors, trigger sensors, controller cabinet and sample parcel are included. The reader proxies are existing generic library geometry, not manufacturer CAD. The arrangement does not establish six-face coverage, visibility, illumination, throughput, conveyor transfer, safety or read performance; no barcode reading or motion is simulated. Sensor positioning and structural dimensions are illustrative.

Cognex describes configurable [DataMan-based modular vision tunnels](https://support.cognex.com/en/products/dataman-380-based-modular-vision-tunnel) and a [bottom-side reader positioned under a belt gap](https://www.cognex.com/library/media/press-release-media/press-release-pdfs/cognex-bottom-side-barcode-reading-system.pdf). These sources inform the concept but do not validate this installation.

`scene.blend` is editable. `equipment.glb` is the browser asset and `mvt.usdc` plus `textures/` is the static USD export. No physics, controls, camera coverage or Isaac Sim rendering is verified. Rebuild with Blender `--python-exit-code 1 --python build.py`.
