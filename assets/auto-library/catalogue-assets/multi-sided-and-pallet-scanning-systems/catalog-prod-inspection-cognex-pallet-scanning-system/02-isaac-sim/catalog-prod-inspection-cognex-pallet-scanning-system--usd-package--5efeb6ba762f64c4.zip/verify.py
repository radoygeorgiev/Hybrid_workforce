from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
p=Path(__file__).resolve().parent/'pallet-scan.usdc';s=Usd.Stage.Open(str(p));assert s
assert str(s.GetDefaultPrim().GetPath())=='/PalletScan'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
_,_,missing=UsdUtils.ComputeAllDependencies(str(p));assert not missing,missing
m=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh');u=sum(1 for x in s.Traverse() if x.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(x).GetPrimvar('st'))
t=sum(1 for x in s.Traverse() if x.GetTypeName()=='Shader' and UsdShade.Shader(x).GetIdAttr().Get()=='UsdUVTexture')
opacity=[]
for x in s.Traverse():
 if x.GetTypeName()=='Shader' and UsdShade.Shader(x).GetIdAttr().Get()=='UsdPreviewSurface':
  i=UsdShade.Shader(x).GetInput('opacity')
  if i and i.Get() is not None and i.Get()<.5:opacity.append(i.Get())
assert m>100 and u>100 and t>=4 and opacity,(m,u,t,opacity)
print('PALLET_SCAN_USD_CHECK',m,u,t,'film opacity',opacity,'no unresolved dependencies')
