# SICK Lector Identification System — illustrative logistics array

An illustrative eight-reader, five-sided arrangement on a continuous belt, reusing the library's Lector85x exterior proxies. The 1 m-class conveyor and eight cameras reflect the published [Logistics Lector Array 5-sided-103 data sheet](https://www.sick.com/media/pdf/9/19/419/dataSheet_Logistics-Lector-Array-5-sided_p677419_en.pdf); actual mounting positions, dimensions, reader housings, optical fields, illuminators, safety and electrical connections are not manufacturer CAD. This static concept does not demonstrate five-face coverage, reading, assignment or conveyor movement.

`scene.blend` is editable, `equipment.glb` is the browser model, and `lector-system.usdc` plus `textures/` is the visual USD export. Physics, controls and Isaac Sim appearance are unverified. Rebuild with Blender `--python-exit-code 1 --python build.py`.
