"""Inspect the composed USD locally, including referenced assets and instances."""
import json
from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
D=Path(__file__).resolve().parent
path=D/'autostore-optimized.usda';stage=Usd.Stage.Open(str(path));assert stage
assert stage.GetDefaultPrim().GetPath().pathString=='/AutoStore'
assert UsdGeom.GetStageUpAxis(stage)==UsdGeom.Tokens.z
assert UsdGeom.GetStageMetersPerUnit(stage)==1
bins=stage.GetPrimAtPath('/AutoStore/StoredBins').GetChildren();assert len(bins)==9116
assert all(p.IsInstance() for p in bins)
assert all(p.GetPrimIndex().IsValid() for p in bins)
_,_,unresolved=UsdUtils.ComputeAllDependencies(str(path));assert not unresolved,unresolved
textures=0;color=0;roughness=0;transparent=0
for prim in stage.Traverse():
 if prim.GetTypeName()!='Shader':continue
 shader=UsdShade.Shader(prim);ident=shader.GetIdAttr().Get()
 if ident=='UsdUVTexture':textures+=1
 if ident=='UsdPreviewSurface':
  for key in ('diffuseColor','roughness'):
   inp=shader.GetInput(key)
   if inp and inp.HasConnectedSource():
    if key=='diffuseColor':color+=1
    else:roughness+=1
  opacity=shader.GetInput('opacity')
  if opacity and opacity.Get() is not None and 0<opacity.Get()<1:transparent+=1
assert textures>=18 and color>=9 and roughness>=8 and transparent>=1,(textures,color,roughness,transparent)
bound=UsdGeom.BBoxCache(Usd.TimeCode.Default(),[UsdGeom.Tokens.default_]).ComputeWorldBound(stage.GetDefaultPrim()).ComputeAlignedRange()
print('USD_VALIDATED',json.dumps({'instance_count':len(bins),'textures':textures,'color_connections':color,'roughness_connections':roughness,'transparent_materials':transparent,'unresolved':unresolved,'min':list(bound.GetMin()),'max':list(bound.GetMax())}),flush=True)
