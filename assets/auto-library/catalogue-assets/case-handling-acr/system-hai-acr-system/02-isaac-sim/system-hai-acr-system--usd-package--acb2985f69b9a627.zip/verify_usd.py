from pxr import Usd,UsdGeom,UsdShade,UsdUtils
from pathlib import Path
import json
D=Path(__file__).resolve().parent;p=D/'hai-system1.usdc';s=Usd.Stage.Open(str(p));assert s
assert str(s.GetDefaultPrim().GetPath())=='/HaiSystem1'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
_,_,unresolved=UsdUtils.ComputeAllDependencies(str(p));assert not unresolved,unresolved
textures=0;color=0;rough=0;uv_meshes=0
for prim in s.Traverse():
 if prim.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(prim).GetPrimvar('st'):uv_meshes+=1
 if prim.GetTypeName()!='Shader':continue
 shader=UsdShade.Shader(prim);ident=shader.GetIdAttr().Get()
 if ident=='UsdUVTexture':textures+=1
 if ident=='UsdPreviewSurface':
  for name in ('diffuseColor','roughness'):
   inp=shader.GetInput(name)
   if inp and inp.HasConnectedSource():
    if name=='diffuseColor':color+=1
    else:rough+=1
assert textures>=8 and color>=4 and rough>=4 and uv_meshes>0,(textures,color,rough,uv_meshes)
print('HAI_SYSTEM1_USD_VALIDATED',json.dumps({'texture_shaders':textures,'color_connections':color,'roughness_connections':rough,'uv_meshes':uv_meshes,'unresolved':unresolved}),flush=True)
