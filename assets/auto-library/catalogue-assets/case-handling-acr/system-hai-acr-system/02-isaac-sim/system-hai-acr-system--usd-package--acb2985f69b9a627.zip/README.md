# HaiPick System 1 visual concept

This illustrative large installation contains six rack aisles, two-deep storage, 4,000 modeled stored totes, twelve case-handling robot proxies and six pick positions with generic order walls. It is a static Blender scene, not manufacturer CAD or an operational simulation. The robot geometry is the existing library's HAI-style approximation and must not be treated as a dimensionally accurate A42 variant. The generic order walls are not represented as HAI products.

The robot's open U-shaped carriage, chassis sensor windows, mast ties and top cover were refined using the published A42 visual as a reference: https://www.hairobotics.com/sites/default/files/2022-09/haipick-a42-robots-overseas.png. The carriage is parked, with no modeled gripper motion or cargo transfer; the dimensions are the library's approximation.

The manufacturer describes System 1 as case-handling robots, racking and workstations, and says certain configurations can reach two totes deep: https://www.hairobotics.com/solutions/haipick-system-1. The A42 family and its differing variants are described at https://www.hairobotics.com/robots/haipick-a42. Dimensions, quantities, layout, workstation arrangement and colors here are concept assumptions, not a specific installation.

The check script verifies selected counts and static aisle positions only. Retrieval reach, robot dimensions, tote custody, station transfer, operating routes, collision envelopes, safety, control logic and visual appearance in Isaac Sim remain unverified. Generic texture maps are not OEM finishes.
