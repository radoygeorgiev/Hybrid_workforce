from pathlib import Path
from pxr import Usd,UsdGeom,UsdUtils,UsdShade
D=Path(__file__).resolve().parent
s=Usd.Stage.Open(str(D/'ident-gate.usdc'));assert s
assert str(s.GetDefaultPrim().GetPath())=='/IdentGate'
assert UsdGeom.GetStageUpAxis(s)==UsdGeom.Tokens.z and UsdGeom.GetStageMetersPerUnit(s)==1
_,_,missing=UsdUtils.ComputeAllDependencies(str(D/'ident-gate.usdc'));assert not missing,missing
meshes=sum(1 for p in s.Traverse() if p.GetTypeName()=='Mesh')
uvs=sum(1 for p in s.Traverse() if p.GetTypeName()=='Mesh' and UsdGeom.PrimvarsAPI(p).GetPrimvar('st'))
textures=sum(1 for p in s.Traverse() if p.GetTypeName()=='Shader' and UsdShade.Shader(p).GetIdAttr().Get()=='UsdUVTexture')
assert meshes>80 and uvs>50 and textures>=4,(meshes,uvs,textures)
print('IDENT_GATE_USD_CHECK',meshes,uvs,textures,'no unresolved dependencies')
