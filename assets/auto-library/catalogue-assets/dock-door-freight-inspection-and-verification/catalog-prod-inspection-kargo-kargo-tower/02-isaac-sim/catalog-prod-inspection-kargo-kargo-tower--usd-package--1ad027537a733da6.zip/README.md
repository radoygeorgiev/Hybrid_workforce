# Kargo Tower — illustrative paired dock installation

This scene contains two approximate tower enclosures beside a dock opening, optical apertures, status screens, impact bollards and a sample pallet. Kargo publishes a [125-inch height and 22.3 × 16.7-inch footprint](https://www.kargo.ai/tower); the model uses those overall dimensions. Enclosure proportions, optics, status display, mounting and dock layout are illustrative. [Mighty Studios' V3 design reference](https://www.mighty-studios.com/work/kargo----v3-tower) describes a folding structure, cameras and integrated lighting, but this model is not manufacturer CAD and the fold is not animated.

`scene.blend` is editable, `equipment.glb` is the browser model and `kargo.usdc` plus `textures/` is the static visual export. Camera coverage, label reading, detection, clearance, safety, controls and Isaac Sim appearance are unverified; nothing is simulated. Rebuild using Blender `--python-exit-code 1 --python build.py`.
