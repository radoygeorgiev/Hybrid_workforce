# ELOshield hardware references

- [ELOKON ELOshield product and technical specifications](https://www.elokon.com/index.php/en-US/material-handling/eloshield-vehicle-pedestrian-proximity-detection): UWB vehicle/pedestrian modules and stationary zoning. Published visualization unit 120 × 125 × 35 mm, vehicle antenna 85 × 58 × 35 mm, pedestrian module 64 × 125 × 14 mm and stationary module 110 × 150 × 40 mm.
- [ELOKON LogiMAT image of devices](https://www.elokon.com/files/aktuelles/Messen-und-Events/LogiMAT/2018/LogiMAT18_DSC_4869.jpg) and [wearable module](https://www.elokon.com/assets/images/e/LogiMAT18_DSC_4931-5174c851.jpg): visual reference for the fascia, rings, indicator lights and acknowledgement control.

Exterior visual reconstruction only. Exact fascia artwork, connectors, fasteners, stationary and antenna enclosure design, mounting feet, materials and device arrangement are inferred. These objects do not perform detection, alerts or speed reduction and are not safety-rated hardware or OEM CAD.
