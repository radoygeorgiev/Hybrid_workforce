Open eloshield.usdc. Static reference-informed visual hardware set, metre units and Z up. The devices are not functional or safety certified. See REFERENCES.md for sources and assumptions.
